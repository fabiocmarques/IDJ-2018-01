//
// Created by Fabio Marques on 06/05/2018.
//

#ifndef T2_BEING_H
#define T2_BEING_H

#include <iostream>
#include <string>

using namespace std;


class Being {
public:
    bool Is(string type);
};


#endif //T2_BEING_H
