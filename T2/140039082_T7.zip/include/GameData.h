//
// Created by fabio on 17/05/18.
//

#ifndef T2_GAMEDATA_H
#define T2_GAMEDATA_H


class GameData {
public:
    static bool playerVictory;
};


#endif //T2_GAMEDATA_H
