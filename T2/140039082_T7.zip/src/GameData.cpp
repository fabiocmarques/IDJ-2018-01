//
// Created by fabio on 17/05/18.
//

#include "GameData.h"

bool GameData::playerVictory = false;