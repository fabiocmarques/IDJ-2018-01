//
// Created by Fabio Marques on 06/05/2018.
//

#include "Being.h"

bool Being::Is(string type) {
    return type == "Being";
}
