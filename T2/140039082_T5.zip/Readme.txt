Aluno: Fábio Marques
Matrícula: 14039082


Compilar o programa:
- Entrar na pasta que contem as pastas "src", "include" e "assets";
- Executar o comando "make";

Executar o programa:
- Após a compilação do programa, executar o comando "./140039082_FabioMarques"

Link para o GitHub: https://github.com/fabiocmarques/IDJ-2018-01/tree/T5
